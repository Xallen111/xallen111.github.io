# 🌐 Simple Personel Website

💕 The project is for beginners. For this reason I took care to keep it simple, you can use and share as you wish.

📦 Contents

- [X] Footer
- [X] Social Media Icons
- [ ] Work History
